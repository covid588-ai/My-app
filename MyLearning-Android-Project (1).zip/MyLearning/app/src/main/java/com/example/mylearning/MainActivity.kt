package com.example.mylearning

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private class Topic(var name: String, var progress: Int)

    private val topics = mutableListOf<Topic>()
    private lateinit var listBox: LinearLayout
    private lateinit var summary: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        setContentView(buildUi())
        render()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F4F6FA"))
            setPadding(dp(16), dp(36), dp(16), dp(12))
        }

        root.addView(TextView(this).apply {
            text = "My Learning"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#1B2A49"))
        })

        summary = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#5B6785"))
            setPadding(0, dp(2), 0, dp(12))
        }
        root.addView(summary)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "What are you learning?"
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    addTopic()
                    true
                } else false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply {
            text = "Add"
            setOnClickListener { addTopic() }
        })
        root.addView(row)

        listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val scroll = ScrollView(this)
        scroll.addView(listBox)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        return root
    }

    private fun addTopic() {
        val name = input.text.toString().trim()
        if (name.isEmpty()) return
        topics.add(0, Topic(name, 0))
        input.setText("")
        save()
        render()
    }

    private fun render() {
        listBox.removeAllViews()
        val done = topics.count { it.progress >= 100 }
        summary.text = if (topics.isEmpty()) "Add your first topic to get started"
        else "${topics.size} topics · $done completed"

        for (t in topics) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE)
                    cornerRadius = dp(12).toFloat()
                }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(10)

            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            top.addView(TextView(this).apply {
                text = if (t.progress >= 100) "✓ ${t.name}" else t.name
                textSize = 17f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.parseColor("#1B2A49"))
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(Button(this).apply {
                text = "✕"
                minWidth = 0
                minimumWidth = 0
                setOnClickListener {
                    topics.remove(t)
                    save()
                    render()
                }
            })
            card.addView(top)

            card.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = t.progress
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            controls.addView(Button(this).apply {
                text = "−10"
                setOnClickListener { change(t, -10) }
            })
            controls.addView(TextView(this).apply {
                text = "${t.progress}%"
                gravity = Gravity.CENTER
                textSize = 16f
                setTextColor(Color.parseColor("#5B6785"))
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            controls.addView(Button(this).apply {
                text = "+10"
                setOnClickListener { change(t, 10) }
            })
            card.addView(controls)

            listBox.addView(card, lp)
        }
    }

    private fun change(t: Topic, delta: Int) {
        t.progress = (t.progress + delta).coerceIn(0, 100)
        save()
        render()
    }

    private fun save() {
        val arr = JSONArray()
        for (t in topics) {
            arr.put(JSONObject().put("name", t.name).put("progress", t.progress))
        }
        getSharedPreferences("learning", MODE_PRIVATE).edit()
            .putString("topics", arr.toString()).apply()
    }

    private fun load() {
        val raw = getSharedPreferences("learning", MODE_PRIVATE).getString("topics", null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                topics.add(Topic(o.getString("name"), o.getInt("progress")))
            }
        } catch (e: Exception) {
            topics.clear()
        }
    }
}
