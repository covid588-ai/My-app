My Learning - Android project

No-install build (GitHub):
1. Create a free account and a new repository at github.com.
2. Upload ALL files from this folder (including the hidden .github folder).
3. Open the Actions tab > "Build APK" > wait for the green check.
4. Open the finished run > Artifacts > download "My-Learning-APK".

With Android Studio: open this folder, then Build > Build APK(s).
